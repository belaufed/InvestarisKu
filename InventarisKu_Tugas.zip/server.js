
import express from "express";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const PORT = process.env.PORT || 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_FILE = path.join(__dirname, "data", "barang.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

async function bacaBarang() {
  const isi = await fs.readFile(DATA_FILE, "utf8");
  return JSON.parse(isi);
}

async function simpanBarang(barang) {
  await fs.writeFile(
    DATA_FILE,
    JSON.stringify(barang, null, 2),
    "utf8"
  );
}

function validasiBarang(body) {
  const nama = String(body.nama ?? "").trim();
  const kategori = String(body.kategori ?? "").trim();
  const lokasi = String(body.lokasi ?? "").trim();
  const jumlah = Number(body.jumlah);

  if (
    !nama ||
    !kategori ||
    !lokasi ||
    body.jumlah === "" ||
    body.jumlah === null ||
    body.jumlah === undefined ||
    !Number.isInteger(jumlah) ||
    jumlah < 0
  ) {
    return null;
  }

  return { nama, kategori, jumlah, lokasi };
}

// GET - Menampilkan seluruh barang
app.get("/api/barang", async (req, res, next) => {
  try {
    const barang = await bacaBarang();
    res.json({
      success: true,
      data: barang
    });
  } catch (error) {
    next(error);
  }
});

// POST - Menambahkan barang
app.post("/api/barang", async (req, res, next) => {
  try {
    const input = validasiBarang(req.body);

    if (!input) {
      return res.status(400).json({
        success: false,
        message: "Data barang tidak valid."
      });
    }

    const barang = await bacaBarang();
    const idBaru = barang.length
      ? Math.max(...barang.map((item) => item.id)) + 1
      : 1;

    const barangBaru = {
      id: idBaru,
      ...input
    };

    barang.push(barangBaru);
    await simpanBarang(barang);

    res.status(201).json({
      success: true,
      message: "Barang berhasil ditambahkan.",
      data: barangBaru
    });
  } catch (error) {
    next(error);
  }
});

// PUT - Mengubah barang
app.put("/api/barang/:id", async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const input = validasiBarang(req.body);

    if (!Number.isInteger(id) || id <= 0 || !input) {
      return res.status(400).json({
        success: false,
        message: "ID atau data barang tidak valid."
      });
    }

    const barang = await bacaBarang();
    const index = barang.findIndex((item) => item.id === id);

    if (index === -1) {
      return res.status(404).json({
        success: false,
        message: "Barang tidak ditemukan."
      });
    }

    barang[index] = {
      id,
      ...input
    };

    await simpanBarang(barang);

    res.json({
      success: true,
      message: "Barang berhasil diperbarui.",
      data: barang[index]
    });
  } catch (error) {
    next(error);
  }
});

// DELETE - Menghapus barang
app.delete("/api/barang/:id", async (req, res, next) => {
  try {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({
        success: false,
        message: "ID barang tidak valid."
      });
    }

    const barang = await bacaBarang();
    const index = barang.findIndex((item) => item.id === id);

    if (index === -1) {
      return res.status(404).json({
        success: false,
        message: "Barang tidak ditemukan."
      });
    }

    const barangDihapus = barang.splice(index, 1)[0];
    await simpanBarang(barang);

    res.json({
      success: true,
      message: "Barang berhasil dihapus.",
      data: barangDihapus
    });
  } catch (error) {
    next(error);
  }
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({
    success: false,
    message: "Terjadi kesalahan pada server."
  });
});

app.listen(PORT, () => {
  console.log(`InventarisKu berjalan di http://localhost:${PORT}`);
});
